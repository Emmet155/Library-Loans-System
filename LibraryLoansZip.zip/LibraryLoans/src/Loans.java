import java.time.LocalDate;
import java.util.List;
import java.util.Scanner;


// -- this class represents a loan transaction in the library --
public class Loans {

    private final String barcode;                // -- Barcode of the borrowed item --
    private final String userID;                // -- UserID of the borrowing user --
    private LocalDate issueDate;               // -- Date when the item was borrowed --
    private LocalDate dueDate;                // -- Due date for returning the item --
    private int Renews;                      // --  Number of times the loan has been renewed --



    // -- a constructor which aim is to initialize these loan attributes --
    public Loans(String barcode, String userID, LocalDate issueDate, LocalDate dueDate, int Renews) {
        this.barcode = barcode;
        this.userID = userID;
        this.issueDate = issueDate;
        this.dueDate = dueDate;
        this.Renews = Renews;
    }


    // -- getter methods for loan attributes --
    public String getBarcode() {
        return barcode;
    }

    public String getUserID() {
        return userID;
    }

    public LocalDate getIssueDate() {
        return issueDate;
    }

    public void setIssueDate(LocalDate issueDate) {
        this.issueDate = issueDate;
    }

    public LocalDate getDueDate() {
        return dueDate;
    }

    public void setDueDate(LocalDate dueDate) {
        this.dueDate = dueDate;
    }

    public int getRenews() {
        return Renews;
    }

    // -- purpose of this method is to get the item associated with this loan from a list of items --
    public Items getItemFromThisLoan(List<Items> items) {
        Items itemLoan = null;


        // -- this is to find the loan's barcode --
        for (Items item : items) {
            if (item.getBarcode().equals(barcode)) {
                itemLoan = item;
                break;
            }
        }

        return itemLoan;
    }

    // -- a method to renew the loan --
    public void renew(List<Items> items) throws RuntimeException {
        Items itemLoan = getItemFromThisLoan(items);


        // -- this is to check if the number of renewals exceeds the maximum renewal period --
        if (this.Renews + 1 > itemLoan.getMaxRenewalPeriod()) {
            throw new RuntimeException("Maximum number of renewals allowed (" + this.Renews + ")");
        }


        // -- this increments the number of renewals and updates the due date --
        this.Renews++;
        this.dueDate = dueDate.plusWeeks(itemLoan.getRenewalPeriod());
    }


    // -- this method returns the loaned item --
    public void returnLoan(List<Items> items) {
        Items itemLoan = getItemFromThisLoan(items);
        LocalDate today = LocalDate.now();

        // -- to see if the item has returned after the due date --
        if (today.isAfter(this.dueDate)) {
            throw new RuntimeException("This item is being returned after its due date (" + this.dueDate + ")");
        }
    }

    // -- this method converts barcode to loan --
    public static Loans fromBarcodeToLoan(List<Loans> loans) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Please provide the barcode of the loan:");
        Loans itemLoan = null;

        while (scanner.hasNext()) {
            String inputBarcode = scanner.next();

            // -- find the loan with the given barcode --
            for (Loans loan : loans) {
                if (loan.getBarcode().equals(inputBarcode)) {
                    itemLoan = loan;
                    break;
                }
            }

            if (itemLoan == null) {
                System.out.println("The barcode " + inputBarcode + " is incorrect or is not associated with any loan");
                System.out.println("Please provide the barcode of the loan:");
                continue;
            }

            break;
        }

        return itemLoan;
    }

    // -- a toString method to display the loan info --
    @Override
    public String toString() {
        return "Barcode: " + barcode.toUpperCase() +
                "; UserID: " + userID.toUpperCase() +
                "; Issue date: " + issueDate +
                "; Due date: " + dueDate +
                "; Renewals: " + Renews;
    }
}
