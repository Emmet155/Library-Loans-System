import java.time.LocalDate;
import java.util.List;
import java.util.Scanner;

// -- books class representing a book item in the library --
public class Books extends Items {


    // a books constructor to initialize these attributes --
    public Books(String barcode, String artist, String title, int year, String IBSN) {
        super(barcode, artist, title, year, IBSN);
    }


    // -- method to get the type of the item such as "Book" --
    @Override
    public String getType () {
        return "Book";
    }

    // -- method to get the loanable period for the book (in weeks) --
    @Override
    public int getLoanablePeriod() {
        return 5;
    }

    // -- method to get the maximum renewal period for the book (in weeks) --
    @Override
    public int getMaxRenewalPeriod() {
        return 3;
    }


    // -- method to get the renewal period for the book (in weeks) --
    @Override
    public int getRenewalPeriod() {
        return 2;
    }
}

