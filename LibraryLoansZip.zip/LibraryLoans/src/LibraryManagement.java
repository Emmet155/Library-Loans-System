import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;


// -- this library management class hands all the library operations and user interface --
public class LibraryManagement {


    // -- file path to get the loans data --
    public static String loans_file = "LOANS.csv";

    // -- a method to load the items from a CSV file --
    public static List<Items> loadItems() {
        final String FILENAME = "ITEMS.csv";
        List<Items> items = new ArrayList<>();

        try {
            File file = new File(FILENAME);
            Scanner scanner = new Scanner(file);


            scanner.nextLine();

            // -- Read the data from file and help create corresponding item objects --
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();

                String[] info = line.split(",");
                // If it's an empty line, skip it
                if (info.length < 5)
                    continue;


                if (info[3].equals("Book"))
                    items.add(new Books(info[0], info[1], info[2], Integer.parseInt(info[4]), info[5]));
                else if (info[3].equals("Multimedia"))
                    items.add(new Multimedia(info[0], info[1], info[2], Integer.parseInt(info[4]), info[5]));
            }

            scanner.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

        return items;
    }


    // -- method to load users from the CSV file --
    public static List<Users> loadUsers() {
        final String FILENAME = "USERS.csv";
        List<Users> users = new ArrayList<>();

        try {
            File file = new File(FILENAME);
            Scanner scanner = new Scanner(file);


            scanner.nextLine();

            // -- read data from file and create corresponding user objects --
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                String[] info = line.split(",");
                // If it's an empty line, skip it
                if (info.length < 3)
                    continue;

                users.add(new Users(info[0], info[1], info[2], info[3]));
            }

            scanner.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

        return users;
    }


    // Method to load loans from a CSV file
    public static List<Loans> loadLoans() {
        final String FILENAME = loans_file;
        List<Loans> loans = new ArrayList<>();

        try {
            File file = new File(FILENAME);
            Scanner scanner = new Scanner(file);


            if (scanner.hasNextLine())
                scanner.nextLine();

            // -- read data from file and create corresponding loan objects --
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                String[] info = line.split(",");
                // If it's an empty line, skip it
                if (info.length < 4)
                    continue;

                loans.add(new Loans(info[0], info[1], LocalDate.parse(info[2]), LocalDate.parse(info[3]), Integer.parseInt(info[4])));
            }

            scanner.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

        return loans;
    }
    // -- another method to save loans to a CSV file --
    public static void saveLoans(List<Loans> loans) {
        try (FileWriter writer = new FileWriter(loans_file)) {
            writer.write("Barcode,UserID,IssueDate,DueDate,Renews\n");
            for (Loans loan : loans) {
                writer.write(loan.getBarcode() + "," + loan.getUserID() + "," + loan.getIssueDate() + "," + loan.getDueDate() + "," + loan.getRenews() + "\n");
            }
            System.out.println("Loans have been saved to " + loans_file);
        } catch (IOException e) {
            System.err.println("Error while saving loans: " + e.getMessage());
        }
    }

    // -- this is the main menu --
    public static void MainMenu() {
        System.out.println("\nWelcome to the Library Management!\n");
        System.out.println("1 - Issue a loan for a user");
        System.out.println("2 - Renew a loan");
        System.out.println("3 - Return a loan");
        System.out.println("4 - View all active loans");
        System.out.println("5 - View report of the loans");
        System.out.println("6 - Generate library Information");
        System.out.println("0 - Exit from the program\n");
        System.out.println("Enter Your Choice:");
    }

    // -- this is the user options --
    public static void UserOptions(String choice, List<Loans> loans, List<Items> items, List<Users> users) {
        switch (choice) {
            case "1":
                issueLoan(loans, items, users);
                break;
            case "2":
                renewLoan(loans, items, users);
                break;
            case "3":
                returnLoan(loans, items, users);
                break;
            case "4":
                viewLoans(loans);
                break;
            case "5":
                viewReport(loans, items);
                break;
            case "6":
                itemInfo(items);
                break;
            case "0":
                exit(loans);
                break;
            default:
                System.out.println("Invalid choice. Please try again.");
                break;
        }
    }

    // -- this method issues a new loan --
    public static void issueLoan(List<Loans> loans, List<Items> items, List<Users> users) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter the UserID:");
        String userID = scanner.nextLine();
        System.out.println("Enter the Barcode:");
        String barcode = scanner.nextLine();

        // -- check if user and item exist --
        Users user = null;
        for (Users u : users) {
            if (u.getUserID().equals(userID)) {
                user = u;
                break;
            }
        }

        Items item = null;
        for (Items i : items) {
            if (i.getBarcode().equals(barcode)) {
                item = i;
                break;
            }
        }

        if (user == null || item == null) {
            System.out.println("User or item not found. Loan can't be issued.");
            return;
        }

        LocalDate today = LocalDate.now();
        LocalDate dueDate = today.plusWeeks(item.getLoanablePeriod());
        Loans loan = new Loans(barcode, userID, today, dueDate, 0);
        loans.add(loan);

        System.out.println("Loan issued successfully:");
        System.out.println(loan);
    }

    // -- this method renews a loan --
    public static void renewLoan(List<Loans> loans, List<Items> items, List<Users> users) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter the Barcode of the loan to renew:");
        String barcode = scanner.nextLine();

        Loans loan = null;
        for (Loans l : loans) {
            if (l.getBarcode().equals(barcode)) {
                loan = l;
                break;
            }
        }

        if (loan == null) {
            System.out.println("Loan has not been found. Can't renew.");
            return;
        }

        Items item = null;
        for (Items i : items) {
            if (i.getBarcode().equals(barcode)) {
                item = i;
                break;
            }
        }

        if (item == null) {
            System.out.println("Item has not been found. Can't renew.");
            return;
        }

        try {
            loan.renew(items);
            System.out.println("Loan renewed successfully.");
            System.out.println("New due date: " + loan.getDueDate());
        } catch (RuntimeException e) {
            System.out.println("Failed to renew loan: " + e.getMessage());
        }
    }

    // -- see all active loans that are present --
    public static void viewLoans(List<Loans> loans) {
        System.out.println("Active Loans:");
        for (Loans loan : loans) {
            System.out.println(loan);
        }
    }

    // -- return a loan --
    public static void returnLoan(List<Loans> loans, List<Items> items, List<Users> users) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter the Barcode of the loan to return:");
        String barcode = scanner.nextLine();

        Loans loanToRemove = null;
        for (Loans loan : loans) {
            if (loan.getBarcode().equals(barcode)) {
                loanToRemove = loan;
                break;
            }
        }

        if (loanToRemove == null) {
            System.out.println("Loan has been not found. Can't return.");
            return;
        }

        try {
            loanToRemove.returnLoan(items);
            loans.remove(loanToRemove);
            System.out.println("Loan returned successful.");
        } catch (RuntimeException e) {
            System.out.println("Failed to return loan: " + e.getMessage());
        }
    }

    // -- method to view a report of these loans --

    public static void viewReport(List<Loans> loans, List<Items> items) {
        int bookLoans = 0;
        int multimediaLoans = 0;
        int renewedLoans = 0;

        for (Loans loan : loans) {
            Items item = loan.getItemFromThisLoan(items);
            if (item instanceof Books) {
                bookLoans++;
            } else if (item instanceof Multimedia) {
                multimediaLoans++;
            }

            if (loan.getRenews() > 0) {
                renewedLoans++;
            }
        }

        System.out.println("Library Report:");
        System.out.println("Number of Book Loans: " + bookLoans);
        System.out.println("Number of Multimedia Loans: " + multimediaLoans);
        System.out.println("Number of Loans Renewed: " + renewedLoans);
    }


    // -- method to print information about an item --
    public static void itemInfo(List<Items> items) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter the Barcode of the item to print information:");
        String barcode = scanner.nextLine();

        Items item = null;
        for (Items i : items) {
            if (i.getBarcode().equals(barcode)) {
                item = i;
                break;
            }
        }

        if (item == null) {
            System.out.println("Item not found.");
        } else {
            System.out.println(item);
        }
    }

    // -- method to exit the program --
    public static void exit(List<Loans> loans) {
        saveLoans(loans);
        System.out.println("Exiting the program.");
    }


    // -- the main method --
    public static void main(String[] args) {
        List<Items> items = loadItems();
        List<Users> users = loadUsers();
        List<Loans> loans = loadLoans();
        Scanner scanner = new Scanner(System.in);
        boolean wantToExit = false;
        while (!wantToExit) {
            MainMenu();
            String choice = scanner.nextLine();
            UserOptions(choice, loans, items, users);
            if (choice.equals("0")) {
                scanner.close();
                wantToExit = true;
            }
        }
    }
}